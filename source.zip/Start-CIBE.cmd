@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Start-CIBE.ps1"
pause
