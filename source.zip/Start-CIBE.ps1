$ErrorActionPreference = 'Stop'
$cibeRoot = $PSScriptRoot
$cibeUrl = 'http://127.0.0.1:5014/'
function Restart-OwnedCibe([int]$cibePort, [string]$cibePidFile) {
    $cibeBeforeRestart = Invoke-RestMethod ('http://127.0.0.1:' + $cibePort + '/api/status') -TimeoutSec 5
    if ($cibeBeforeRestart.activeJobs -gt 0) { throw 'CIBE is still generating a life or report. Wait until the result appears, then run this launcher again.' }
    $cibeSavedPid = [int](Get-Content -LiteralPath (Join-Path $cibeRoot $cibePidFile))
    $cibeOwnedProcess = Get-CimInstance Win32_Process -Filter "ProcessId = $cibeSavedPid"
    $cibeListener = Get-NetTCPConnection -LocalPort $cibePort -State Listen -ErrorAction Stop
    if ($cibeOwnedProcess.Name -ne 'node.exe' -or $cibeOwnedProcess.CommandLine -notmatch 'server\.mjs' -or $cibeListener.OwningProcess -ne $cibeSavedPid) { throw 'CIBE process ownership could not be verified. No process was stopped.' }
    $cibeRunningModel = @(Get-CimInstance Win32_Process -Filter "ParentProcessId = $cibeSavedPid" | Where-Object { $_.Name -eq 'codex.exe' })
    if ($cibeRunningModel.Count -gt 0) { throw 'A CIBE model request is still running. Wait for it to finish, then run this launcher again.' }
    Stop-Process -Id $cibeSavedPid -ErrorAction Stop
    Start-Sleep -Seconds 1
}
$cibeStatus = $null
try { $cibeStatus = Invoke-RestMethod ($cibeUrl + 'api/status') -TimeoutSec 5 } catch {}
if ($cibeStatus.service -eq 'cibe-life-ai' -and $cibeStatus.protocol -eq 2 -and $cibeStatus.revision -lt 6) {
    Restart-OwnedCibe 5014 'server.pid'
    $cibeStatus = $null
}
if ($cibeStatus.service -ne 'cibe-life-ai') {
    if (Get-NetTCPConnection -LocalPort 5014 -State Listen -ErrorAction SilentlyContinue) {
        throw 'Port 5014 is in use by another service. Close that service before starting CIBE.'
    }
    $cibeNode = Join-Path $env:USERPROFILE '.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe'
    if (-not (Test-Path -LiteralPath $cibeNode)) { $cibeNode = (Get-Command node -ErrorAction Stop).Source }
    $cibeProcess = Start-Process -FilePath $cibeNode -ArgumentList @('server.mjs') -WorkingDirectory $cibeRoot -WindowStyle Hidden -RedirectStandardOutput (Join-Path $cibeRoot 'server.stdout.log') -RedirectStandardError (Join-Path $cibeRoot 'server.stderr.log') -PassThru
    Set-Content -LiteralPath (Join-Path $cibeRoot 'server.pid') -Value $cibeProcess.Id
    for ($cibeAttempt = 0; $cibeAttempt -lt 15; $cibeAttempt++) {
        Start-Sleep -Seconds 1
        try { $cibeStatus = Invoke-RestMethod ($cibeUrl + 'api/status') -TimeoutSec 3; break } catch {}
    }
    if ($cibeStatus.service -ne 'cibe-life-ai') { throw 'CIBE could not start. Check server.stderr.log.' }
}
if ($cibeStatus.protocol -ne 2) {
    # Keep the existing frontend and its browser storage origin intact.
    $cibeBackendUrl = 'http://127.0.0.1:5015/'
    $cibeBackendStatus = $null
    try { $cibeBackendStatus = Invoke-RestMethod ($cibeBackendUrl + 'api/status') -TimeoutSec 5 } catch {}
    if ($cibeBackendStatus.service -eq 'cibe-life-ai' -and $cibeBackendStatus.protocol -eq 2 -and $cibeBackendStatus.revision -lt 6) {
        Restart-OwnedCibe 5015 'server-v2.pid'
        $cibeBackendStatus = $null
    }
    if ($cibeBackendStatus.service -ne 'cibe-life-ai' -or $cibeBackendStatus.protocol -ne 2) {
        if (Get-NetTCPConnection -LocalPort 5015 -State Listen -ErrorAction SilentlyContinue) { throw 'Port 5015 is occupied. CIBE has not stopped any other process.' }
        $cibeNode = Join-Path $env:USERPROFILE '.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe'
        if (-not (Test-Path -LiteralPath $cibeNode)) { $cibeNode = (Get-Command node -ErrorAction Stop).Source }
        $cibeProcess = Start-Process -FilePath $cibeNode -ArgumentList @('server.mjs','5015') -WorkingDirectory $cibeRoot -WindowStyle Hidden -RedirectStandardOutput (Join-Path $cibeRoot 'server-v2.stdout.log') -RedirectStandardError (Join-Path $cibeRoot 'server-v2.stderr.log') -PassThru
        Set-Content -LiteralPath (Join-Path $cibeRoot 'server-v2.pid') -Value $cibeProcess.Id
        for ($cibeAttempt = 0; $cibeAttempt -lt 15; $cibeAttempt++) {
            Start-Sleep -Seconds 1
            try { $cibeBackendStatus = Invoke-RestMethod ($cibeBackendUrl + 'api/status') -TimeoutSec 3; break } catch {}
        }
        if ($cibeBackendStatus.protocol -ne 2) { throw 'The updated backend could not start. Check server-v2.stderr.log.' }
    }
    $cibeStatus = $cibeBackendStatus
}
Write-Host ('CIBE: ' + $cibeUrl)
Write-Host ('AI connection available: ' + $cibeStatus.available)
Write-Host 'Ready. Return to your existing CIBE browser tab and refresh it.'
Write-Host 'Use the same browser to keep access to your saved life archives.'
