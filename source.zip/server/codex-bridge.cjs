'use strict';
const fs=require('node:fs'),path=require('node:path'),os=require('node:os'),crypto=require('node:crypto');
const {spawn,execFile}=require('node:child_process');
// Adapted from the user's GuanTu v0.3 local bridge; credentials remain managed by Codex.
const DEFAULT_MODEL='gpt-6.1-terra';
const DEFAULT_REASONING='low';
const DISABLED=['apps','plugins','memories','shell_tool','computer_use','browser_use','image_generation','multi_agent','hooks','skill_search','view_image','sleep_tool','shell_snapshot'];
let cachedStatus=null;
function executable(){
  const candidates=[process.env.CODEX_CLI_PATH];
  for(const dir of (process.env.PATH||'').split(path.delimiter))candidates.push(path.join(dir,process.platform==='win32'?'codex.exe':'codex'));
  const root=path.join(process.env.LOCALAPPDATA||'', 'OpenAI','Codex','bin');
  if(process.platform==='win32'&&fs.existsSync(root)){
    const installed=fs.readdirSync(root,{withFileTypes:true}).filter(e=>e.isDirectory()).map(e=>path.join(root,e.name,'codex.exe')).filter(f=>fs.existsSync(f));
    installed.sort((a,b)=>fs.statSync(b).mtimeMs-fs.statSync(a).mtimeMs);candidates.push(...installed);
  }
  return candidates.find(f=>f&&path.isAbsolute(f)&&fs.existsSync(f)&&fs.statSync(f).isFile())||null;
}
function command(file,args,options={}){return new Promise(resolve=>execFile(file,args,{windowsHide:true,timeout:10000,maxBuffer:65536,...options},(error,stdout,stderr)=>resolve({ok:!error,text:String(stdout||'')+'\n'+String(stderr||'')})));}
function authEnvironment(){
  const env={...process.env};
  // Let the official CLI use its own saved login. Never read or copy credentials.
  for(const key of Object.keys(env))if((key.startsWith('CODEX_')&&key!=='CODEX_HOME')||['OPENAI_API_KEY','OPENAI_BASE_URL'].includes(key))delete env[key];
  return env;
}
function proxyAddress(value){
  if(!value)return null;
  const parts=value.trim().split(';');
  const entry=parts.find(p=>/^https=/i.test(p))||parts.find(p=>/^http=/i.test(p))||parts.find(p=>!p.includes('='));
  if(!entry)return null;
  const address=entry.replace(/^https?=/i,'').trim();
  try{const u=new URL(address.includes('://')?address:'http://'+address);return ['http:','https:'].includes(u.protocol)&&!u.username&&!u.password?u.origin:null;}catch{return null;}
}
async function networkEnvironment(){
  const env=authEnvironment();
  if(process.platform==='win32'&&!env.HTTPS_PROXY&&!env.https_proxy&&!env.ALL_PROXY&&!env.all_proxy){
    const reg=path.join(process.env.SystemRoot||'C:\\Windows','System32','reg.exe');
    const r=await command(reg,['query','HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings']);
    if(r.ok&&/ProxyEnable\s+REG_DWORD\s+0x1\b/i.test(r.text)){
      const proxy=proxyAddress(r.text.match(/ProxyServer\s+REG_SZ\s+([^\r\n]+)/i)?.[1]);
      if(proxy){env.HTTPS_PROXY=proxy;env.HTTP_PROXY=proxy;}
    }
  }
  return env;
}
async function status(){
  if(cachedStatus&&Date.now()-cachedStatus.at<10000)return {...cachedStatus.value};
  const file=executable();let value;
  if(!file)value={available:false,loggedIn:false,model:DEFAULT_MODEL,message:'这台电脑未找到 Codex，请先安装并登录 Codex，然后刷新 CIBE 页面。'};
  else{
    const result=await command(file,['login','status'],{env:authEnvironment()});
    const loggedIn=result.ok&&/Logged in using ChatGPT/i.test(result.text);
    value={available:true,loggedIn,model:DEFAULT_MODEL,message:loggedIn?'本机 Codex 已登录，可以直接连接。':'请先在本机 Codex 中登录 ChatGPT，再刷新 CIBE 页面。'};
  }
  cachedStatus={at:Date.now(),value};return {...value};
}
function prepareInput(messages,dir){
  if(!Array.isArray(messages)||messages.length>100)throw Error('模型消息格式无效');
  const instructions=[],images=[],lines=[];let bytes=0;
  for(const message of messages){
    if(['system','developer'].includes(message.role)){
      if(typeof message.content!=='string')throw Error('模型指令格式无效');
      instructions.push(message.content);continue;
    }
    lines.push(`Message role: ${message.role==='assistant'?'assistant':'user'}`);
    const parts=typeof message.content==='string'?[{type:'text',text:message.content}]:message.content;
    if(!Array.isArray(parts))throw Error('模型消息内容无效');
    for(const part of parts){
      if(part.type==='text'&&typeof part.text==='string')lines.push(part.text);
      else if(part.type==='image_url'){
        const m=/^data:image\/(png|jpeg|webp);base64,([A-Za-z0-9+/=]+)$/.exec(part.image_url?.url||'');
        if(!m||m[2].length>18e6||images.length>=42)throw Error('图片格式、数量或大小不支持');
        const data=Buffer.from(m[2],'base64');bytes+=data.length;if(bytes>30e6)throw Error('图片总大小超过限制');
        const file=path.join(dir,`image-${images.length+1}.${m[1]==='jpeg'?'jpg':m[1]}`);fs.writeFileSync(file,data);
        images.push(file);lines.push(`[Attached image ${images.length}; the images are attached in this exact order.]`);
      }else throw Error('不支持的模型输入类型');
    }
  }
  const developerInstructions='This is an independent CIBE life scenario inference request. Use only the supplied conversation and task data. Do not use tools, access files, browse, or modify anything. When asked for a simulated function call, return its JSON representation only; never execute it. Return only the requested JSON object, without markdown or commentary.\n'+instructions.join('\n\n');
  return {images,prompt:lines.join('\n\n'),developerInstructions};
}
function publicError(text){
  if(/unauthorized|login|authentication|401/i.test(text))return 'Codex 登录已失效，请在 Codex 中重新登录后重试。';
  if(/usage limit|rate limit|quota|429/i.test(text))return '当前 Codex 额度或调用频率受限，请稍后重试。';
  if(/timed out|timeout|connect|network|stream disconnected/i.test(text))return '模型连接超时，请确认本机网络和代理正在运行，再重试。';
  if(/model.*not.*(found|support|available)|not.*access.*model/i.test(text))return '当前 Codex 账号无法使用已选模型，请检查账号的模型权限。';
  return 'Codex 未完成本次模型调用，请稍后重试。';
}
async function complete(cfg,messages,options={}){
  const model=cfg.model;
  if(!['gpt-6-astra','gpt-6.1-terra'].includes(model))throw Error('本机连接不支持所选模型');
  const reasoningEffort=options.reasoningEffort||DEFAULT_REASONING;
  if(!['low','medium'].includes(reasoningEffort))throw Error('不支持的推演思考强度');
  const file=executable();if(!file)throw Error('未找到本机 Codex');
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'cibe-life-model-'));
  let child;
  try{
    const input=prepareInput(messages,dir),env=await networkEnvironment();
    if(options.signal?.aborted)throw new DOMException('Aborted','AbortError');
    const args=['exec','--ignore-user-config','--ephemeral','--skip-git-repo-check','--sandbox','read-only','--json','--color','never','--model',model,'--cd',dir,
      '-c','approval_policy="never"','-c','project_doc_max_bytes=0','-c','web_search="disabled"','-c','model_reasoning_effort='+JSON.stringify(reasoningEffort),
      '-c','developer_instructions='+JSON.stringify(input.developerInstructions),'--enable','skip_host_skill_discovery'];
    for(const flag of DISABLED)args.push('--disable',flag);
    if(options.outputSchema){
      const schemaPath=path.join(dir,'response.schema.json');
      fs.writeFileSync(schemaPath,JSON.stringify(options.outputSchema),'utf8');
      args.push('--output-schema',schemaPath);
    }
    const finalPath=path.join(dir,'final-message.txt');
    args.push('--output-last-message',finalPath);
    for(const image of input.images)args.push('--image',image);
    args.push('-');
    const result=await new Promise((resolve,reject)=>{
      let buffer='',size=0,content='',threadId=null,usage=null,completed=false,failed=false,problem='',forcedError=null,stderr='',killTimer=null,settled=false;
      child=spawn(file,args,{cwd:dir,env,windowsHide:true,shell:false,stdio:['pipe','pipe','pipe']});
      const rejectWithAudit=error=>{error.bridge={transport:'codex-cli',adapterVersion:'1.0',imageCount:input.images.length,threadId,completed,raw:content||null,usage};reject(error);};
      const stop=error=>{
        if(forcedError)return;forcedError=error;child.kill();
        killTimer=setTimeout(()=>{
          if(settled)return;
          // This PID belongs to the process spawned by this request only.
          if(process.platform==='win32'&&child.pid)execFile(path.join(process.env.SystemRoot||'C:\\Windows','System32','taskkill.exe'),['/PID',String(child.pid),'/T','/F'],{windowsHide:true,timeout:5000},()=>{});
          child.stdout.destroy();child.stderr.destroy();child.stdin.destroy();child.unref();
          settled=true;clearTimeout(timer);options.signal?.removeEventListener('abort',abort);rejectWithAudit(forcedError);
        },3000);
      };
      const abort=()=>stop(new DOMException('Aborted','AbortError'));
      const timer=setTimeout(abort,options.timeoutMs||180000);
      options.signal?.addEventListener('abort',abort,{once:true});
      if(options.signal?.aborted)abort();
      const event=line=>{
        if(!line.trim())return;
        let e;try{e=JSON.parse(line);}catch{stop(Error('Codex 返回了无法读取的事件'));return;}
        if(!e||typeof e!=='object'||typeof e.type!=='string'){stop(Error('Codex 返回了无效的事件格式'));return;}
        if(e.type==='item.completed'&&e.item?.type==='agent_message'&&typeof e.item.text!=='string'){stop(Error('Codex 返回了无效的文字结果'));return;}
        if(e.type==='thread.started')threadId=e.thread_id;
        if(e.type==='item.completed'&&e.item?.type==='agent_message')content=e.item.text||'';
        if(e.type?.startsWith('item.')&&e.item?.type&&!['agent_message','reasoning','error'].includes(e.item.type))stop(Error('模型尝试执行判断任务以外的操作，本次结果已拒绝。'));
        if(e.item?.type==='error')problem=e.item.message||'';
        if(e.type==='turn.completed'){completed=true;usage=e.usage||null;}
        if(e.type==='turn.failed'){failed=true;problem=e.error?.message||e.message||'';}
        if(e.type==='error')problem=e.message||'';
      };
      child.stdout.setEncoding('utf8');child.stdout.on('data',chunk=>{
        size+=Buffer.byteLength(chunk);if(size>2e6){stop(Error('模型响应过大'));return;}
        buffer+=chunk;let n;while((n=buffer.indexOf('\n'))>=0){const line=buffer.slice(0,n);buffer=buffer.slice(n+1);event(line);}
      });
      child.stderr.setEncoding('utf8');child.stderr.on('data',chunk=>{if(stderr.length<8000)stderr+=chunk.slice(0,8000-stderr.length);});
      child.stdin.on('error',()=>{});child.stdin.end(input.prompt);
      child.on('error',()=>{forcedError=Error('无法启动本机 Codex，请重新打开 Codex 后重试。');});
      child.on('close',code=>{
        if(settled)return;clearTimeout(timer);clearTimeout(killTimer);options.signal?.removeEventListener('abort',abort);if(buffer.trim())event(buffer);
        settled=true;clearTimeout(killTimer);
        if(forcedError)return rejectWithAudit(forcedError);
        // Prefer the CLI's final answer artifact over intermediate agent messages.
        if(fs.existsSync(finalPath)){
          if(fs.statSync(finalPath).size>2e6)return rejectWithAudit(Error('模型响应过大'));
          const final=fs.readFileSync(finalPath,'utf8');if(final.trim())content=final;
        }
        if(code!==0||failed||!completed||!content.trim())return rejectWithAudit(Error(publicError(problem+' '+stderr)));
        resolve({content,threadId,usage});
      });
    });
    return {id:result.threadId||crypto.randomUUID(),model,choices:[{message:{content:result.content},finish_reason:'stop'}],usage:result.usage,
      bridge:{transport:'codex-cli',adapterVersion:'1.1',modelSource:'explicit-cli-selection',reasoningEffort,ephemeral:true,userConfigLoaded:false,projectInstructionsLoaded:false,
        imageCount:input.images.length,inputMapping:'images attached in original message order',developerInstructions:input.developerInstructions,promptSha256:crypto.createHash('sha256').update(input.prompt).digest('hex')}};
  }finally{
    // Only remove the unique directory created by this call, never a caller-provided path.
    if(path.dirname(dir)===path.resolve(os.tmpdir())&&path.basename(dir).startsWith('cibe-life-model-')){
      try{fs.rmSync(dir,{recursive:true,force:true,maxRetries:3,retryDelay:100});}
      catch{
        console.warn('CIBE: temporary image cleanup is pending; retrying shortly.');
        setTimeout(()=>{try{fs.rmSync(dir,{recursive:true,force:true,maxRetries:3,retryDelay:100});}catch{console.warn('CIBE: temporary images could not be removed from the system temporary folder.');}},5000).unref();
      }
    }
  }
}
module.exports={DEFAULT_MODEL,DEFAULT_REASONING,status,complete,prepareInput,proxyAddress};
