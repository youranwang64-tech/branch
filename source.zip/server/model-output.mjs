const string={type:'string'};
const stringList={type:'array',items:string};
const object=properties=>({type:'object',properties,required:Object.keys(properties),additionalProperties:false});
export const reportSchema=object({summary:string,causalChain:stringList,tradeoffs:stringList,questions:stringList,assumptions:stringList});
export function nodesSchema(ids){return object({nodes:{type:'array',minItems:ids.length,maxItems:ids.length,items:object({id:{type:'string',enum:ids},title:string,summary:string,detail:string,effects:stringList})}});}

// Strip transport decoration only. Never execute text or invent missing JSON fields.
export function parseModelObject(raw){
  if(typeof raw!=='string'||raw.length>200000)throw new SyntaxError('Invalid model text');
  let text=raw.replace(/^\uFEFF/,'').trim();
  const fence=/^```(?:json)?\s*\n?([\s\S]*?)\n?```$/i.exec(text);
  if(fence)text=fence[1].trim();
  let result;
  try{result=JSON.parse(text);}catch{
    // Some providers add a sentence around a complete JSON object.
    let start=-1,depth=0,inString=false,escaped=false;const candidates=[];
    for(let i=0;i<text.length;i++){
      const c=text[i];
      if(start<0){if(c==='{'){start=i;depth=1;}continue;}
      if(inString){if(escaped)escaped=false;else if(c==='\\')escaped=true;else if(c==='"')inString=false;continue;}
      if(c==='"')inString=true;
      else if(c==='{')depth++;
      else if(c==='}'&&--depth===0){candidates.push(text.slice(start,i+1));start=-1;}
    }
    if(start!==-1||candidates.length!==1)throw new SyntaxError('Incomplete or ambiguous model JSON');
    result=JSON.parse(candidates[0]);
  }
  if(!result||typeof result!=='object'||Array.isArray(result))throw new SyntaxError('Expected model object');
  return result;
}

export async function generateChecked(bridge,messages,schema,validate,onRepair=()=>{}){
  const deadline=Date.now()+180000;
  for(let attempt=0;attempt<2;attempt++){
    const remaining=deadline-Date.now();if(remaining<1000)throw Error('本次格式核对超时，原档案已保留，请重试。');
    const result=await bridge.complete({model:bridge.DEFAULT_MODEL||'gpt-6.1-terra'},messages,{timeoutMs:remaining,outputSchema:schema});
    try{return validate(parseModelObject(result.choices?.[0]?.message?.content));}
    catch(error){
      if(attempt===1)throw Error('这一批内容仍未通过格式检查，原档案和输入已保留，请重试。');
      onRepair();
    }
  }
}
