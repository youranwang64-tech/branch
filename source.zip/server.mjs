import {createLifeServer} from './server/life-service.mjs';
const port=Number(process.argv[2]||5014);
if(![5014,5015].includes(port))throw Error('Unsupported CIBE port');
createLifeServer({port}).listen(port,'127.0.0.1',()=>console.log('CIBE + GPT-6.1 Terra: http://127.0.0.1:'+port+'/'));
