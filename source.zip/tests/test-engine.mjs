import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { webcrypto } from 'node:crypto';
globalThis.crypto ||= webcrypto;
const source = await readFile(new URL('../dist/engine.js', import.meta.url), 'utf8');
const { createLife, branchLife, buildReport, validateSession } = await import('data:text/javascript;base64,' + Buffer.from(source).toString('base64'));

const profile = { name: '小林', age: 22, stage: 'university', vision: '建立自己的工作室', education: 'work', work: '视觉设计', priority: 'freedom', question: '先就业还是读研' };
const base = createLife(profile);
assert.equal(base.nodes.length, 6);
assert.deepEqual(base.nodes.map(n => n.id), ['start', 'education', 'career', 'city', 'turning', 'ending']);
assert.equal(base.nodes[0].options.length, 0);
assert.ok(base.nodes.every((node, i) => i === 0 || node.age > base.nodes[i - 1].age));
const before = JSON.stringify(base);
const study = branchLife(base, 'education', { id: 'study' });
assert.equal(JSON.stringify(base), before, 'branching must not mutate baseline');
assert.deepEqual(study.nodes[0], base.nodes[0]);
for (let i = 1; i < 6; i++) assert.notDeepEqual(study.nodes[i], base.nodes[i], `node ${i} must respond to changed education`);
assert.equal(study.choices.education.id, 'study');
assert.equal(study.parentId, base.id);
assert.equal(study.changes.length, 1);
const city = branchLife(study, 'city', { id: 'move' });
assert.deepEqual(city.nodes.slice(0, 3), study.nodes.slice(0, 3), 'history before city remains untouched');
assert.equal(city.choices.education.id, 'study', 'earlier explicit choice retained');
assert.equal(city.changes.length, 2);
assert.match(city.nodes[5].summary, /继续学习/);
assert.match(city.nodes[5].summary, /去新的城市/);
assert.notEqual(city.nodes[5].summary, study.nodes[5].summary);
const custom = branchLife(city, 'career', { id: 'custom', label: '在家乡创办独立书店' });
assert.equal(custom.choices.city.id, 'move', 'later existing choice remains explicit when forking earlier');
assert.deepEqual(custom.nodes.slice(0, 2), city.nodes.slice(0, 2));
for (const node of custom.nodes.slice(2)) assert.match(node.detail, /在家乡创办独立书店/);
assert.equal(custom.changes.length, 3);
const sameAgain = branchLife(city, 'career', { id: 'custom', label: '在家乡创办独立书店' });
assert.deepEqual(custom.nodes, sameAgain.nodes, 'same conditions yield deterministic narratives');
const otherProfile = createLife({ ...profile, stage: 'working', education: 'study', priority: 'connection' });
assert.notDeepEqual(base.nodes, otherProfile.nodes);
assert.notEqual(base.nodes[0].title, otherProfile.nodes[0].title);
const report = buildReport({ profile, lives: [base, study, city, custom], activeLifeId: custom.id });
assert.match(report, /本地情景演示/);
assert.match(report, /小林/);
assert.match(report, /分支 3/);
assert.match(report, /在家乡创办独立书店/);
assert.throws(() => branchLife(base, 'start', { id: 'study' }));
assert.throws(() => branchLife(base, 'city', { id: 'invalid' }));
assert.throws(() => branchLife(base, 'city', { id: 'custom', label: ' ' }));
assert.throws(() => buildReport({}));
assert.equal(createLife({ age: 'bad' }).profile.age, 22);
assert.equal(createLife({ priority: '__proto__', stage: '__proto__' }).profile.priority, 'growth');
assert.equal(createLife({ age: 15 }).profile.age, 22);
assert.equal(createLife({ age: 81 }).profile.age, 22);
assert.equal(createLife({ age: 16 }).profile.age, 16);
assert.equal(createLife({ age: 80 }).profile.age, 80);
assert.throws(() => branchLife(base, 'education', { id: 'work' }), { message: '选择没有变化，请尝试另一个方向。' });
assert.throws(() => branchLife(custom, 'career', { id: 'custom', label: '在家乡创办独立书店', description: '另一个说明' }), { message: '选择没有变化，请尝试另一个方向。' });

const validArchive = {
  schemaVersion: 1, code: 'CIBE-ABCD1234', isDemo: false, profile: base.profile,
  lives: [base, study, city, custom], activeLifeId: custom.id,
};
assert.equal(validateSession(validArchive), true, 'generated archive is valid');
assert.equal(validateSession(JSON.parse(JSON.stringify(validArchive))), true, 'JSON round-trip remains valid');
assert.equal(validateSession({ ...validArchive, exportedAt: new Date().toISOString() }), true, 'download metadata accepted');
function rejected(mutator, message) {
  const archive = structuredClone(validArchive);
  mutator(archive);
  assert.equal(validateSession(archive), false, message);
}
rejected(s => { s.lives[2].changes = [{ nodeId: 'city' }]; }, 'damaged changes rejected');
rejected(s => { delete s.lives[1].choices; }, 'missing choices rejected');
rejected(s => { s.lives[1].parentId = 'missing-parent'; }, 'missing parent rejected');
rejected(s => { s.lives[1].parentId = s.lives[3].id; }, 'forward parent reference rejected');
rejected(s => { s.lives[2].changes = [s.lives[2].change]; }, 'parent history must be retained');
rejected(s => { s.lives[1].change.before = '伪造的先前选择'; }, 'forged before label rejected');
rejected(s => { s.lives[1].change.after = '伪造的新选择'; }, 'forged after label rejected');
rejected(s => { s.lives[2].choices.education = s.lives[0].choices.education; }, 'unrecorded concurrent changes rejected');
rejected(s => { s.lives[0].nodes[4].summary = '伪造节点内容'; }, 'nodes must match profile and choices');
rejected(s => { s.lives[1].nodes[3].effects = null; }, 'missing field type rejected');
rejected(s => { s.lives[1].nodes[3].id = 'bad'; }, 'node IDs rejected');
rejected(s => { s.lives[1].profile.name = '另一个玩家'; }, 'mismatched profiles rejected');
rejected(s => { s.profile.age = '22'; }, 'age must be integer number');
rejected(s => { s.profile.age = 15; }, 'age out of range rejected');
rejected(s => { s.profile.stage = 'wrong'; }, 'stage enum enforced');
rejected(s => { s.profile.name = '长'.repeat(41); }, 'profile lengths enforced');
rejected(s => { s.activeLifeId = 'missing'; }, 'active life must exist');
rejected(s => { s.lives[1].id = s.lives[0].id; }, 'duplicate life IDs rejected');
rejected(s => { s.code = 'CIBE-abc'; }, 'code format enforced');
rejected(s => { s.schemaVersion = 2; }, 'schema enforced');
rejected(s => { s.lives[1].mode = 'real-model'; }, 'only local demo archives supported');
rejected(s => { s.lives[1].createdAt = 'bad'; }, 'timestamps validated');
rejected(s => { s.lives = []; }, 'empty lives rejected');
assert.equal(validateSession(null), false);
assert.equal(validateSession({}), false);
assert.equal(validateSession({ ...validArchive, lives: Array(101).fill(base) }), false);
const reordered = structuredClone(validArchive);
reordered.profile = Object.fromEntries(Object.entries(reordered.profile).reverse());
assert.equal(validateSession(reordered), true, 'JSON property order is not significant');
const continued = branchLife(validArchive.lives.at(-1), 'ending', { id: 'focus' });
assert.equal(validateSession({ ...validArchive, lives: [...validArchive.lives, continued], activeLifeId: continued.id }), true, 'validated import can safely continue branching');
console.log('PASS: scenario generation, same-choice guard, age bounds, strict import validation, tamper rejection, preserved branch history and continued branching.');

// Full-life horizons use broad chapters; late starters still get ordered stages.
for (const age of [16,22,34,65,80]) {
 const life=createLife({...profile,age});
 assert.equal(life.timelineVersion,1);
 assert.ok(life.nodes.at(-1).age>=90);
 assert.ok(life.nodes.every((n,i)=>!i||n.age-life.nodes[i-1].age>=5));
 const fork=branchLife(life,'city',{id:'move'});
 assert.deepEqual(fork.nodes.map(n=>n.age),life.nodes.map(n=>n.age));
 assert.equal(fork.timelineVersion,1);
}
