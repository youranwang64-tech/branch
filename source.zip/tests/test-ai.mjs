import test from 'node:test';
import assert from 'node:assert/strict';
import {createLife,branchLife,applyAIResult,applyAINodes,applyAIReport,validateSession,buildReport} from '../dist/engine.js';
import {createLifeServer} from '../server/life-service.mjs';
const profile={name:'测试玩家',age:22,stage:'university',vision:'用创作连接人与地方',education:'work',work:'设计',priority:'freedom',question:'先工作还是先学习？'};
const fixture=life=>({nodes:life.nodes.slice(life.changedNodeId?life.nodes.findIndex(n=>n.id===life.changedNodeId):1).map(n=>({id:n.id,title:'探索'+n.category,summary:'为新方向安排具体的尝试。',detail:'这是一段测试用的生成内容，用于验证归档与分支保留。',effects:['需要时间','需要反馈']})),report:{summary:'测试用报告。',causalChain:['选择改变安排'],tradeoffs:['时间与支出'],questions:['需要哪些信息？'],assumptions:['具备基本生活支持']}});
const wrap=life=>({schemaVersion:1,code:'CIBE-AITEST01',profile:life.profile,isDemo:false,lives:[life],activeLifeId:life.id});
test('AI archives preserve and validate all earlier events and include report',()=>{
  const base=applyAIResult(createLife(profile),fixture(createLife(profile)));
  const session=wrap(base);assert.equal(validateSession(session),true);
  const draft=branchLife(base,'city',{id:'custom',label:'到乡村生活一年',description:'玩家选择'});
  const next=applyAIResult(draft,fixture(draft));
  session.lives.push(next);session.activeLifeId=next.id;
  assert.equal(validateSession(session),true);
  assert.deepEqual(next.nodes.slice(0,3),base.nodes.slice(0,3));
  assert.match(buildReport(session),/AI 人生报告/);
  assert.equal(validateSession(JSON.parse(JSON.stringify(session))),true);
  const tampered=structuredClone(session);tampered.lives[1].nodes[1].detail='修改过去的经历';
  assert.equal(validateSession(tampered),false);
});
test('Malformed output cannot replace an existing life',()=>{
  const base=createLife(profile),before=JSON.stringify(base);
  const invalid=fixture(base);invalid.nodes[0].id='ending';
  assert.throws(()=>applyAIResult(base,invalid));
  assert.equal(JSON.stringify(base),before);
});

test('Terra branches coexist with earlier Astra lives and retain accurate report attribution',()=>{
  const baseDraft=createLife(profile),base=applyAIResult(baseDraft,fixture(baseDraft));
  const draft=branchLife(base,'city',{id:'custom',label:'去乡村生活',description:'玩家选择'});
  const next=applyAINodes(draft,fixture(draft).nodes,'gpt-6.1-terra');
  const withReport=applyAIReport(next,fixture(draft).report,'gpt-6.1-terra');
  const session={...wrap(base),lives:[base,withReport],activeLifeId:next.id};
  assert.equal(validateSession(session),true);
  assert.equal(validateSession(JSON.parse(JSON.stringify(session))),true);
  assert.deepEqual(next.nodes.slice(0,3),base.nodes.slice(0,3));
  assert.equal(base.generation.model,'gpt-6-astra');assert.match(buildReport(session),/GPT-6\.1 Terra/);
  const older=structuredClone(session);delete older.lives[0].aiReport.model;assert.equal(validateSession(older),true);
  const malformed=structuredClone(session);malformed.lives[1].generation.model='unknown';assert.equal(validateSession(malformed),false);
});
test('CIBE HTTP jobs enforce origin/auth and return failures without demo fallback',async()=>{
  let fail=false;
  const fake={status:async()=>({loggedIn:true,message:'test'}),complete:async(_,messages)=>{
    if(fail)throw Error('模拟模型断线');
    const data=JSON.parse(messages[1].content);
    const life=createLife(data.profile);
    return {choices:[{message:{content:JSON.stringify({nodes:fixture(life).nodes.filter(n=>data.requiredNodes.some(r=>r.id===n.id))})}}]};
  }};
  const port=5021,server=createLifeServer({port,modelBridge:fake});
  await new Promise(r=>server.listen(port,'127.0.0.1',r));
  try{
    const base='http://127.0.0.1:'+port;
    const state=await (await fetch(base+'/api/status')).json();
    assert.equal(state.service,'cibe-life-ai');
    const headers={'Content-Type':'application/json','X-CIBE-Token':state.token};
    assert.equal((await fetch(base+'/api/life/jobs',{method:'POST',body:'{}'})).status,403);
    assert.equal((await fetch(base+'/api/life/jobs',{method:'POST',headers:{...headers,Origin:'https://external.example'},body:'{}'})).status,403);
    const start=async()=>{const r=await fetch(base+'/api/life/jobs',{method:'POST',headers,body:JSON.stringify({kind:'generate',profile})});assert.equal(r.status,202);return (await r.json()).id;};
    const id=await start();
    const result=await (await fetch(base+'/api/life/jobs/'+id,{headers})).json();
    assert.equal(result.state,'completed');assert.equal(result.life.mode,'ai');
    fail=true;
    const failed=await (await fetch(base+'/api/life/jobs/'+await start(),{headers})).json();
    assert.equal(failed.state,'failed');assert.equal(failed.life,undefined);
    assert.equal((await fetch(base+'/server/codex-bridge.cjs')).status,404);
  }finally{await new Promise(r=>server.close(r));}
});

test('Node-only archives round trip, deferred reports preserve nodes, branches clear old reports',()=>{
  const draft=createLife(profile),base=applyAINodes(draft,fixture(draft).nodes);
  assert.equal(base.aiReport,null);assert.equal(validateSession(wrap(base)),true);
  assert.equal(validateSession(JSON.parse(JSON.stringify(wrap(base)))),true);
  const reported=applyAIReport(base,fixture(draft).report);
  assert.deepEqual(reported.nodes,base.nodes);assert.equal(base.aiReport,null);
  const branch=branchLife(reported,'city',{id:'custom',label:'在家乡做驻地创作',description:'玩家选择'});
  const generated=applyAINodes(branch,fixture(branch).nodes);
  assert.equal(generated.aiReport,null);
  assert.deepEqual(generated.nodes.slice(0,3),reported.nodes.slice(0,3));
  assert.equal(validateSession({...wrap(reported),lives:[reported,generated],activeLifeId:generated.id}),true);
  assert.throws(()=>applyAIReport(base,{summary:'incomplete'}));
});

test('Progress exposes validated first node before remaining nodes; report is lazy and cached',async()=>{
  let release;const gate=new Promise(r=>release=r);const calls=[];
  const fake={status:async()=>({loggedIn:true}),complete:async(_,messages)=>{
    const data=JSON.parse(messages[1].content);calls.push(data);
    if(calls.length===2)await gate;
    const output=data.requiredNodes?{nodes:fixture(createLife(data.profile)).nodes.filter(n=>data.requiredNodes.some(r=>r.id===n.id))}:fixture(createLife(data.profile)).report;
    return {choices:[{message:{content:JSON.stringify(output)}}]};
  }};
  const port=5022,server=createLifeServer({port,modelBridge:fake});await new Promise(r=>server.listen(port,'127.0.0.1',r));
  const base='http://127.0.0.1:'+port;
  try{
    const state=await (await fetch(base+'/api/status')).json();assert.equal(state.protocol,2);
    const headers={'Content-Type':'application/json','X-CIBE-Token':state.token};
    const start=async payload=>{const r=await fetch(base+'/api/life/jobs',{method:'POST',headers,body:JSON.stringify(payload)});assert.equal(r.status,202);return (await r.json()).id;};
    const get=async id=>(await fetch(base+'/api/life/jobs/'+id,{headers})).json();
    const finish=async id=>{for(let i=0;i<100;i++){const j=await get(id);if(j.state!=='running')return j;await new Promise(r=>setTimeout(r,5));}throw Error('Job did not finish');};
    const id=await start({kind:'generate',profile});const partial=await get(id);
    assert.equal(partial.state,'running');assert.equal(partial.nodes.length,1);assert.equal(partial.life,undefined);assert.equal(partial.total,5);
    assert.equal(calls[1].alreadyGenerated[0].id,'education');
    release();const completed=await finish(id);assert.equal(completed.state,'completed');assert.equal(completed.life.aiReport,null);assert.equal(calls.length,2);
    const session=wrap(completed.life);assert.equal(validateSession(session),true);
    const reported=await finish(await start({kind:'report',session}));assert.equal(calls.length,3);
    assert.deepEqual(reported.life.nodes,completed.life.nodes);assert.ok(reported.life.aiReport);
    session.lives=[reported.life];await finish(await start({kind:'report',session}));assert.equal(calls.length,3,'cached report does not invoke model again');
  }finally{release();await new Promise(r=>server.close(r));}
});

test('A later batch failure cannot commit a partial branch or alter its parent',async()=>{
  const draft=createLife(profile),parent=applyAINodes(draft,fixture(draft).nodes),session=wrap(parent),before=JSON.stringify(session);
  let count=0;const requested=[];
  const fake={status:async()=>({loggedIn:true}),complete:async(_,messages)=>{
    const data=JSON.parse(messages[1].content);requested.push(data.requiredNodes.map(n=>n.id));
    if(++count===2)throw Error('模拟后续节点失败');
    return {choices:[{message:{content:JSON.stringify({nodes:fixture(draft).nodes.filter(n=>data.requiredNodes.some(r=>r.id===n.id))})}}]};
  }};
  const port=5023,server=createLifeServer({port,modelBridge:fake});await new Promise(r=>server.listen(port,'127.0.0.1',r));
  const base='http://127.0.0.1:'+port;
  try{
    const state=await (await fetch(base+'/api/status')).json(),headers={'Content-Type':'application/json','X-CIBE-Token':state.token};
    const res=await fetch(base+'/api/life/jobs',{method:'POST',headers,body:JSON.stringify({kind:'branch',session,nodeId:'city',choice:{id:'custom',label:'去乡村创作',description:'玩家选择'}})});
    const {id}=await res.json();const failed=await (await fetch(base+'/api/life/jobs/'+id,{headers})).json();
    assert.equal(failed.state,'failed');assert.equal(failed.life,undefined);assert.equal(failed.nodes.length,1);
    assert.deepEqual(requested,[['city'],['turning','ending']]);assert.equal(JSON.stringify(session),before);
  }finally{await new Promise(r=>server.close(r));}
});

