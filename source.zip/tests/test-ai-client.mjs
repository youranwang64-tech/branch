import test from 'node:test';
import assert from 'node:assert/strict';

test('Refresh resumes the same task; completed result survives until archive save acknowledges it',async()=>{
  const original={fetch:globalThis.fetch,localStorage:globalThis.localStorage,location:globalThis.location};
  const storage=new Map();let posts=0,polls=0,offline=true;
  globalThis.localStorage={getItem:k=>storage.get(k)??null,setItem:(k,v)=>storage.set(k,v)};
  globalThis.location={hostname:'127.0.0.1',port:'5014'};
  globalThis.fetch=async(url,options)=>{
    if(url==='/api/status')return Response.json({service:'cibe-life-ai',available:true,protocol:2,token:'test-token'});
    if(options?.method==='POST'){posts++;return Response.json({id:'job-1'},{status:202});}
    polls++;if(offline)throw Error('simulated connection interrupted');
    return Response.json({state:'completed',message:'done',life:{id:'life-1',mode:'ai',aiReport:null}});
  };
  try{
    const payload={kind:'generate',profile:{name:'测试'}};
    const first=await import('../dist/ai-client.js?first');await first.aiReady;
    await assert.rejects(first.inferLife(payload),/interrupted/);assert.equal(posts,1);
    assert.equal(first.pendingTasks().length,1);
    offline=false;
    const refreshed=await import('../dist/ai-client.js?refreshed');await refreshed.aiReady;
    assert.equal((await refreshed.inferLife(refreshed.pendingTasks()[0].payload)).id,'life-1');assert.equal(posts,1);
    const beforePolls=polls;
    const afterCompletion=await import('../dist/ai-client.js?completed');await afterCompletion.aiReady;
    assert.equal((await afterCompletion.inferLife(payload)).id,'life-1');assert.equal(polls,beforePolls);
    afterCompletion.acknowledgeTask(payload);assert.equal(afterCompletion.pendingTasks().length,0);
  }finally{Object.assign(globalThis,original);}
});

test('Old local frontend discovers the updated backend without moving browser archives',async()=>{
  const original={fetch:globalThis.fetch,localStorage:globalThis.localStorage,location:globalThis.location};
  const requested=[];
  globalThis.localStorage={getItem:()=>null,setItem:()=>{}};
  globalThis.location={hostname:'127.0.0.1',port:'5014'};
  globalThis.fetch=async url=>{requested.push(url);return Response.json({service:'cibe-life-ai',available:true,protocol:url.startsWith('http:')?2:1,token:'test'});};
  try{
    const client=await import('../dist/ai-client.js?fallback');const state=await client.aiReady;
    assert.equal(state.available,true);assert.equal(state.protocol,2);
    assert.deepEqual(requested,['/api/status','http://127.0.0.1:5015/api/status']);
  }finally{Object.assign(globalThis,original);}
});
