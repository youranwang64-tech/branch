import test from 'node:test';
import assert from 'node:assert/strict';
import {parseModelObject,generateChecked,nodesSchema} from '../server/model-output.mjs';
test('Model JSON accepts fences and prose, but never guesses truncated data or ambiguous objects',()=>{
  const value={nodes:[{id:'education',detail:'包含 } 和 " 引号以及反斜线 \\ 的正文'}]},json=JSON.stringify(value);
  for(const raw of [json,'\uFEFF'+json,'```json\n'+json+'\n```','结果如下：\n'+json+'\n完成。'])assert.deepEqual(parseModelObject(raw),value);
  for(const raw of [json.slice(0,-2),json+json,'{"nodes":[{"id":"education"}', '[]','null','plain text'])assert.throws(()=>parseModelObject(raw));
});
test('Only one format retry, always schema constrained; transport errors do not duplicate requests',async()=>{
  let calls=0,repairs=0;
  const schema=nodesSchema(['education']);
  const bridge={complete:async(_,messages,options)=>{
    calls++;assert.equal(options.outputSchema,schema);
    return {choices:[{message:{content:calls===1?'incomplete':'{"nodes":[]}'}}]};
  }};
  const out=await generateChecked(bridge,[],schema,v=>v,()=>repairs++);
  assert.deepEqual(out,{nodes:[]});assert.equal(calls,2);assert.equal(repairs,1);
  calls=0;
  await assert.rejects(generateChecked({complete:async()=>{calls++;throw Error('offline');}},[],schema,v=>v),/offline/);
  assert.equal(calls,1);
  calls=0;
  await assert.rejects(generateChecked({complete:async()=>{calls++;return {choices:[{message:{content:'{"nodes":[]}'}}]};}},[],schema,()=>{throw Error('wrong shape');}),/仍未通过/);
  assert.equal(calls,2);
});
