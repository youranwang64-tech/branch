import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import vm from 'node:vm';
test('Busy inference preserves native story disclosure clicks and still blocks duplicate actions',async()=>{
  const source=await readFile(new URL('../dist/app.js',import.meta.url),'utf8');
  const begin=source.indexOf("document.addEventListener('click',");
  const end=source.indexOf('\n});',begin)+4;
  let click;
  vm.runInNewContext(source.slice(begin,end),{aiBusy:true,document:{addEventListener:(type,handler)=>{assert.equal(type,'click');click=handler;}}});
  let prevented=false;
  click({target:{closest:()=>null},preventDefault:()=>prevented=true});
  assert.equal(prevented,false,'summary default toggle must not be prevented');
  click({target:{closest:()=>({dataset:{action:'edit-node'}})},preventDefault:()=>prevented=true});
  assert.equal(prevented,true,'busy task still blocks state-changing app buttons');
});
