import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFile} from 'node:fs/promises';

test('Branch preview shows the choice before waiting for AI, then forwards real results without committing archives',async()=>{
  const source=await readFile(new URL('../dist/app.js',import.meta.url),'utf8');
  const code=source.slice(source.indexOf('async function runGraphAI('),source.indexOf('async function runAI('));
  const events=[];
  const payload={kind:'branch',nodeId:'city',choice:{label:'回到家乡'},session:{lives:[]}};
  const before=JSON.stringify(payload);
  const context={aiBusy:false,closeModal:()=>events.push('close'),render:()=>events.push('render'),requestAnimationFrame:cb=>cb(),
    network:{beginPreview:(id,label)=>events.push(['choice',id,label]),updatePreview:n=>events.push(['result',n])},
    inferLife:async(p,cb)=>{events.push('request');cb('完成一个节点',{nodes:[{id:'city',title:'新故事'}]});return {id:'complete'};}};
  vm.createContext(context);vm.runInContext(code,context);
  const result=await context.runGraphAI(payload);
  assert.equal(result.id,'complete');assert.equal(context.aiBusy,false);
  assert.ok(events.findIndex(e=>Array.isArray(e)&&e[0]==='choice')<events.indexOf('request'));
  assert.ok(events.some(e=>Array.isArray(e)&&e[0]==='result'));
  assert.equal(JSON.stringify(payload),before);
  context.inferLife=async()=>{throw Error('offline');};
  await assert.rejects(context.runGraphAI(payload),/offline/);
  assert.equal(events.at(-1),'render','failed previews restore the saved graph');
  assert.equal(context.aiBusy,false);
});
